/*global document*/


//first task is to create the item of navbar 
const unorderedList = document.getElementById('unordered-list');
unorderedList.style.padding = '10px';

const header = document.getElementById('header');
header.style.backgroundColor = 'black';
header.style.backgroundAttachment = 'fixed';
header.style.width = '100%';


//we need to know how many sections we have so we need to get length
const sectionsLength = document.getElementsByClassName('landing__container').length;


//get id of the active section to can use it

for (var i = 1; i <= sectionsLength; i++) {
  //TargetId = "#section" + i;

  //append li to the ul in the html and create li that i times
  const newLi = document.createElement('li');

  unorderedList.appendChild(newLi); //Done to here

  //styling li
  newLi.style.border = '#e3e3e3 solid 2px';
  newLi.style.margin = '5px';

  ////append a to the li in the html and create a that i times
  const newA = document.createElement('a');

  newA.setAttribute("href", "#section" + i);
  newA.textContent = "section" + i;
  newA.setAttribute("id", "a" + i);
  //styling the new a
  newA.style.textDecoration = 'none';
  newA.style.color = 'white';
  newA.style.fontSize = '20px';
  newA.style.margin = "10px";
  newA.style.fontFamily = 'tahoma';

  // final action = append the items
  newLi.appendChild(newA);


}




/*
//second task === sommothly move


for (var i = 1; i <= sectionsLength; i++) {

    var x = "a" + i;

    const targetLink = document.getElementById(x);

    targetLink.style.color = 'lightgreen';




    $(targetLink).on('click', function (e) {

        if (this.hash !== '') {
            e.preventDefault();

            const hash = this.hash;

            $('html, body').animate(

                {

                    scrollTop: $(hash).offset().top
                }, 8000);
        }

    });


}



*/


// another solution for the scrooling smoothly

var scroll = new SmoothScroll('a[href*="#"]');
